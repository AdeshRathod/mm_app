class AppRoutes {
  static const splash = '/splash';
  static const onboarding = '/onboarding';
  static const login = '/login';
  static const registration = '/registration';
  static const forgot_password = '/forgot_password';
  static const change_password = '/change_password';
  static const home = '/home';
  static const profile = '/profile';
  static const update_profile = '/update_profile';
  static const search_profile = '/search_profile';
  static const contact_us = '/contact_us';
  static const about_us = '/about_us';
  static const success_stories = '/success_stories';
  static const all_profiles = '/all_profiles';
  static const single_profile = '/single_profile';
}
