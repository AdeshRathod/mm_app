import 'package:get/get.dart';
import 'app_routes.dart';
import '../modules/splash/splash_screen.dart';
import '../modules/splash/splash_binding.dart';
import '../modules/onboarding/onboarding_screen.dart';
import '../modules/onboarding/onboarding_binding.dart';
import '../modules/login/login_screen.dart';
import '../modules/login/login_binding.dart';
import '../modules/registration/registration_screen.dart';
import '../modules/registration/registration_binding.dart';
import '../modules/forgot_password/forgot_password_screen.dart';
import '../modules/forgot_password/forgot_password_binding.dart';
import '../modules/change_password/change_password_screen.dart';
import '../modules/change_password/change_password_binding.dart';
import '../modules/home/home_screen.dart';
import '../modules/home/home_binding.dart';
import '../modules/profile/profile_screen.dart';
import '../modules/profile/profile_binding.dart';
import '../modules/update_profile/update_profile_screen.dart';
import '../modules/update_profile/update_profile_binding.dart';
import '../modules/search_profile/search_profile_screen.dart';
import '../modules/search_profile/search_profile_binding.dart';
import '../modules/contact_us/contact_us_screen.dart';
import '../modules/contact_us/contact_us_binding.dart';
import '../modules/about_us/about_us_screen.dart';
import '../modules/about_us/about_us_binding.dart';
import '../modules/success_stories/success_stories_screen.dart';
import '../modules/success_stories/success_stories_binding.dart';
import '../modules/all_profiles/all_profiles_screen.dart';
import '../modules/all_profiles/all_profiles_binding.dart';
import '../modules/single_profile/single_profile_screen.dart';
import '../modules/single_profile/single_profile_binding.dart';

class AppPages {

  static List<GetPage> pages = [
    GetPage(
      name: AppRoutes.splash,
      page: () => SplashScreen(),
      binding: SplashBinding(),
    ),
    GetPage(
      name: AppRoutes.onboarding,
      page: () => OnboardingScreen(),
      binding: OnboardingBinding(),
    ),
    GetPage(
      name: AppRoutes.login,
      page: () => LoginScreen(),
      binding: LoginBinding(),
    ),
    GetPage(
      name: AppRoutes.registration,
      page: () => RegistrationScreen(),
      binding: RegistrationBinding(),
    ),
    GetPage(
      name: AppRoutes.forgot_password,
      page: () => ForgotPasswordScreen(),
      binding: ForgotPasswordBinding(),
    ),
    GetPage(
      name: AppRoutes.change_password,
      page: () => ChangePasswordScreen(),
      binding: ChangePasswordBinding(),
    ),
    GetPage(
      name: AppRoutes.home,
      page: () => HomeScreen(),
      binding: HomeBinding(),
    ),
    GetPage(
      name: AppRoutes.profile,
      page: () => ProfileScreen(),
      binding: ProfileBinding(),
    ),
    GetPage(
      name: AppRoutes.update_profile,
      page: () => UpdateProfileScreen(),
      binding: UpdateProfileBinding(),
    ),
    GetPage(
      name: AppRoutes.search_profile,
      page: () => SearchProfileScreen(),
      binding: SearchProfileBinding(),
    ),
    GetPage(
      name: AppRoutes.contact_us,
      page: () => ContactUsScreen(),
      binding: ContactUsBinding(),
    ),
    GetPage(
      name: AppRoutes.about_us,
      page: () => AboutUsScreen(),
      binding: AboutUsBinding(),
    ),
    GetPage(
      name: AppRoutes.success_stories,
      page: () => SuccessStoriesScreen(),
      binding: SuccessStoriesBinding(),
    ),
    GetPage(
      name: AppRoutes.all_profiles,
      page: () => AllProfilesScreen(),
      binding: AllProfilesBinding(),
    ),
    GetPage(
      name: AppRoutes.single_profile,
      page: () => SingleProfileScreen(),
      binding: SingleProfileBinding(),
    ),
  ];
}
