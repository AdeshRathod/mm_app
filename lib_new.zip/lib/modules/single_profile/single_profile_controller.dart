import 'package:get/get.dart';

class SingleProfileController extends GetxController {
  @override
  void onInit() {
    super.onInit();
  }

}
