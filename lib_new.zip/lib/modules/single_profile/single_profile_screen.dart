import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'single_profile_controller.dart';

class SingleProfileScreen extends StatefulWidget {
  const SingleProfileScreen({Key? key}) : super(key: key);

  @override
  SingleProfileState createState() => SingleProfileState();
}

class SingleProfileState extends State<SingleProfileScreen> {
  @override
  Widget build(BuildContext context) {
    return GetBuilder<SingleProfileController>(
      builder: (controller) => Scaffold(
        body: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          color: Colors.white,
        ),
      ),
    );
  }
}
