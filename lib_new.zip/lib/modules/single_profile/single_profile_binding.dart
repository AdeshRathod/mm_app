import 'package:get/get.dart';
import 'single_profile_controller.dart';
class SingleProfileBinding extends Bindings {
  @override
  void dependencies() {
      Get.lazyPut<SingleProfileController>(() => SingleProfileController());
  }
}
