import 'package:get/get.dart';

class UpdateProfileController extends GetxController {
  @override
  void onInit() {
    super.onInit();
  }

}
