import 'package:get/get.dart';

class RegistrationController extends GetxController {
  @override
  void onInit() {
    super.onInit();
  }

}
