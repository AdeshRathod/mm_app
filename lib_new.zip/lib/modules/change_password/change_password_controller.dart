import 'package:get/get.dart';

class ChangePasswordController extends GetxController {
  @override
  void onInit() {
    super.onInit();
  }

}
