import 'package:get/get.dart';

class ContactUsController extends GetxController {
  @override
  void onInit() {
    super.onInit();
  }

}
