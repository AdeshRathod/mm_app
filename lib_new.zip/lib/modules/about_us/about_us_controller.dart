import 'package:get/get.dart';

class AboutUsController extends GetxController {
  @override
  void onInit() {
    super.onInit();
  }

}
