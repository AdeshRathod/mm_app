import 'package:get/get.dart';

class OnboardingController extends GetxController {
  @override
  void onInit() {
    super.onInit();
  }

}
