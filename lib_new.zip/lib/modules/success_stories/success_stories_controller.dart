import 'package:get/get.dart';

class SuccessStoriesController extends GetxController {
  @override
  void onInit() {
    super.onInit();
  }

}
