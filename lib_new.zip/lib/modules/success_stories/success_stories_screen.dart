import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'success_stories_controller.dart';

class SuccessStoriesScreen extends StatefulWidget {
  const SuccessStoriesScreen({Key? key}) : super(key: key);

  @override
  SuccessStoriesState createState() => SuccessStoriesState();
}

class SuccessStoriesState extends State<SuccessStoriesScreen> {
  @override
  Widget build(BuildContext context) {
    return GetBuilder<SuccessStoriesController>(
      builder: (controller) => Scaffold(
        body: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          color: Colors.white,
        ),
      ),
    );
  }
}
