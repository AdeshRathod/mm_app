import 'package:get/get.dart';

class ForgotPasswordController extends GetxController {
  @override
  void onInit() {
    super.onInit();
  }

}
