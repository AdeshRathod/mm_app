import 'package:get/get.dart';
import 'all_profiles_controller.dart';
class AllProfilesBinding extends Bindings {
  @override
  void dependencies() {
      Get.lazyPut<AllProfilesController>(() => AllProfilesController());
  }
}
