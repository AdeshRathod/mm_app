import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'all_profiles_controller.dart';

class AllProfilesScreen extends StatefulWidget {
  const AllProfilesScreen({Key? key}) : super(key: key);

  @override
  AllProfilesState createState() => AllProfilesState();
}

class AllProfilesState extends State<AllProfilesScreen> {
  @override
  Widget build(BuildContext context) {
    return GetBuilder<AllProfilesController>(
      builder: (controller) => Scaffold(
        body: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          color: Colors.white,
        ),
      ),
    );
  }
}
