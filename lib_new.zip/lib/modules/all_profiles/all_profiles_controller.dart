import 'package:get/get.dart';

class AllProfilesController extends GetxController {
  @override
  void onInit() {
    super.onInit();
  }

}
