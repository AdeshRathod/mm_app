import 'package:get/get.dart';

class SearchProfileController extends GetxController {
  @override
  void onInit() {
    super.onInit();
  }

}
