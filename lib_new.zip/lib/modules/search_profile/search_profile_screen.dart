import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'search_profile_controller.dart';

class SearchProfileScreen extends StatefulWidget {
  const SearchProfileScreen({Key? key}) : super(key: key);

  @override
  SearchProfileState createState() => SearchProfileState();
}

class SearchProfileState extends State<SearchProfileScreen> {
  @override
  Widget build(BuildContext context) {
    return GetBuilder<SearchProfileController>(
      builder: (controller) => Scaffold(
        body: Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          color: Colors.white,
        ),
      ),
    );
  }
}
