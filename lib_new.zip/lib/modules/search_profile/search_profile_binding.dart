import 'package:get/get.dart';
import 'search_profile_controller.dart';
class SearchProfileBinding extends Bindings {
  @override
  void dependencies() {
      Get.lazyPut<SearchProfileController>(() => SearchProfileController());
  }
}
