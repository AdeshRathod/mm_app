import 'package:flutter/material.dart';

class CustomThemeExtension extends ThemeExtension<CustomThemeExtension> {
  final Color customColor;

  CustomThemeExtension({required this.customColor});

  @override
  CustomThemeExtension copyWith({Color? customColor}) {
    return CustomThemeExtension(
      customColor: customColor ?? this.customColor,
    );
  }

  @override
  CustomThemeExtension lerp(
      covariant ThemeExtension<CustomThemeExtension>? other, double t) {
    if (other is! CustomThemeExtension) {
      return this;
    }
    return CustomThemeExtension(
      customColor: Color.lerp(customColor, other.customColor, t)!,
    );
  }
}
