import 'package:flutter/material.dart';
import 'app_colours.dart';

class AppTheme {
  static ThemeData get lightTheme => ThemeData(
        primaryColor: AppColours.primaryColor,
        scaffoldBackgroundColor: Colors.white,
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSwatch().copyWith(
          secondary: AppColours.secondaryColor,
        ),
      );
}
