class AppImages {
  static const String logo = 'assets/images/logo.png';
  static const String background = 'assets/images/background.png';

  //
  static const footerLogo= "assets/images/footer_logo.png";
  static const sliderTwo= "assets/images/slider2.jpg";

  static const onboardingOne= "assets/images/onboarding_one.jpg";
  static const onboardingTwo= "assets/images/onboarding_two.jpg";
  static const onboardingThree= "assets/images/onboarding_three.jpg";

}
