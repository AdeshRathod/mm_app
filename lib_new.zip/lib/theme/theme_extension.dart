import 'package:flutter/material.dart';

extension CustomThemeExtension on ThemeData {
  Color get customPrimaryColor => this.primaryColor;
  Color get customSecondaryColor => this.colorScheme.secondary;
}
