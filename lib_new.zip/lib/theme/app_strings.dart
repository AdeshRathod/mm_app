class AppStrings {
  static const String appName = 'My App';
  static const String welcomeMessage = 'Welcome to My App!';
}
