import 'package:flutter/material.dart';

class AppColours {
  static const Color primaryColor = Color(0xffD62E21);
  static const Color secondaryColor = Color(0xffECA518);
}
