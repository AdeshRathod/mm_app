import 'package:app/theme/app_colours.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'theme/theme.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'app',
      theme: AppTheme.lightTheme,
      home: Scaffold(
        appBar: AppBar(backgroundColor: AppColours.primaryColor,title: Text('Home')),
        body: Center(child: Text('Welcome to app')),
      ),
    );
  }
}
